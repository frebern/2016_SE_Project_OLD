package com.android.sdk.api;

import com.android.sdk.common.RequestBundle;
import com.android.sdk.common.RequestListener;
import com.android.sdk.common.ResponseMessage;
import com.android.sdk.common.SDKConstants.eSmartHttpMethod;
import com.android.sdk.common.SDKException;

/***
 * 
 * 
 */
interface APIRequestInterface {

	public ResponseMessage request(RequestBundle bundle) throws SDKException;

	public ResponseMessage request(RequestBundle bundle, eSmartHttpMethod httpMethod) throws SDKException;
	
	public ResponseMessage request(RequestBundle bundle, String url, eSmartHttpMethod httpMethod) throws SDKException;

	public void request(RequestBundle bundle, RequestListener requestListener) throws SDKException ;
	public void request(RequestBundle bundle, eSmartHttpMethod httpMethod, RequestListener requestListener) throws SDKException ;
	public void request(RequestBundle bundle, String url, eSmartHttpMethod httpMethod, RequestListener requestListener) throws SDKException ;

	
}
