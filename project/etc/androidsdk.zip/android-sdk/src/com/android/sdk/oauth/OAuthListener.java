package com.android.sdk.oauth;

public interface OAuthListener {
	public void onComplete(String completeInfo);
	public void onError(String errorMessage);

}
