package com.android.sdk.util;

import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Base64;

public class Encrypt {

	private String kKEY;
	private String kIV;

	/**
	 * @param kKEY
	 * <br>
	 *            SecretKey를 지정한다.
	 **/
	public void setkKey(String kKEY) {
		this.kKEY = kKEY;
	}

	/**
	 * 
	 * @param kIV
	 * <br>
	 *            Initialization Vector 값을 지정한다.
	 **/
	public void setkIV(String kIV) {
		this.kIV = kIV;
	}

	/**
	 * @return kKEY <br>
	 *         SecretKey를 전달한다.
	 **/
	public String getkKey() {
		return kKEY;
	}

	/**
	 * @return kIV <br>
	 *         Initialization Vector 값을 전달한다.
	 **/
	public String getkIV() {
		return kIV;
	}

	/**
	 * @param inputText
	 * <br>
	 *            암호화 할 텍스트
	 * 
	 * @param type
	 * <br>
	 *            암복호화 선택 (true : 암호화, false : 복호화)
	 * 
	 * @return <br>
	 *         암,복호화된 텍스트
	 **/
	public String getEncrypt(String inputText) {

		try {
			BouncyCastleProvider provider = new BouncyCastleProvider();
			// Security.addProvider(new BouncyCastleProvider());
			Security.addProvider(provider);
			IvParameterSpec ivSpec = null;
			SecretKeySpec key = null;
			Cipher cipher = null;
			
			ivSpec = new IvParameterSpec(kIV.getBytes());
			key = new SecretKeySpec(kKEY.getBytes("utf-8"), "AES");
			cipher = Cipher.getInstance("AES/CBC/PKCS7Padding", provider);

			// 결과
//			if (type) {
				// 암호화
				cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);

				byte[] cipherText = cipher.doFinal(inputText.getBytes("UTF-8"));
//				String encode = new String(Base64.encode(cipherText));
				// String encode = hexToBinary(cipherText.toString());

				return hexToBinary(cipherText);
//			} else {
//				// 복호화
//				cipher.init(Cipher.DECRYPT_MODE, key, ivSpec); // CBC 일때만 호출
//				String decode = new String(cipher.doFinal(Base64
//						.decode(inputText.getBytes("UTF-8"))), "UTF-8");
//				//
//
//				// byte[] decode = cipher.doFinal(inputText.getBytes("UTF-8"));
//				return decode;
//			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
		return null;
	}
	
	 

	public static String hexToBinary(byte[] ba) {
		if (ba == null || ba.length == 0) {
			return null;
		}
		
		StringBuffer sb = new StringBuffer(ba.length * 2);
		String hexNumber;
		
		for (int x = 0; x < ba.length; x++) {
	        hexNumber = "0" + Integer.toHexString(0xff & ba[x]);
	        sb.append(hexNumber.substring(hexNumber.length() - 2));
	    }
		
//		long i = Long.parseLong(sb.toString());
//		String Bin = Long.toBinaryString(i);
		return sb.toString();
	}
//		
//	private String hexToBinary(String Hex) {
//		int i = Integer.parseInt(Hex);
//		String Bin = Integer.toBinaryString(i);
//		return Bin;
//	}

}
