package com.android.sdk.common;

public class SDKConstants {

	public static String SDK_VERSION_PREFIX = "SDK Android/";
	public static String SDK_VERSION = "1.0.0";
	
	public static boolean IS_DEBUG = false;
	
	public static enum eSmartContentType {
		XML, JSON
	};

	public static enum eSmartHttpMethod {
		GET, PUT, POST, DELETE
	};

	public static String getContentType(eSmartContentType type) {
		String contentTypeString = "";

		switch (type) {
		case XML:
			contentTypeString = "application/xml";
			break;
		case JSON:
			contentTypeString = "application/json";
			break;
		default:
			contentTypeString = "error";
			break;
		}

		return contentTypeString;

	}
	
	public static final String HEADER_CLIENT_ID 		= "client_id";
	public static final String HEADER_ACCESS_TOKEN 	= "access_token";
	public static final String HEADER_REFRESH_TOKEN 	= "refresh_token";

	/*** 
	 * Error Code
	 */
	public static final String ESmartError001 = "HttpMethod is null";
	public static final String ESmartError002 = "Url is null or empty";

	public static final String ESmartError004 = "ASynchronous Listener is null";
	public static final String ESmartError005 = "Header infomation is null";
	
}
