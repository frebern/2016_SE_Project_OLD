package com.android.sdk.common;


/***
 * 비동기 호출에 대한 응답케이스
 * 
 */
public interface RequestListener {

	public void onComplete(ResponseMessage response);

	public void onSDKException(SDKException e);

}
