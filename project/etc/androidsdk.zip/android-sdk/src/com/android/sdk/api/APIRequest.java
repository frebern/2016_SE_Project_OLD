package com.android.sdk.api;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.KeyStore;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.sdk.common.RequestBundle;
import com.android.sdk.common.RequestListener;
import com.android.sdk.common.ResponseMessage;
import com.android.sdk.common.SDKConstants;
import com.android.sdk.common.SDKConstants.eSmartContentType;
import com.android.sdk.common.SDKConstants.eSmartHttpMethod;
import com.android.sdk.common.SDKException;
import com.android.sdk.oauth.Constants;
import com.android.sdk.util.Encrypt;

/***
 * HttpConnection 구현부.<br>
 * PAYLOAD 가 실리는 부는 Http Method 기본 통신으로 POST 설정.<br>
 * URL 및 QS, PP 만 사용되서 호출하는 부는 기본으로 GET으로 호출.- 물론 설정으로 변경가능함.<br>
 * 
 */
public class APIRequest implements APIRequestInterface {

	private static HttpHeaders httpHeader = null;

	private static String clientId = null;

	public APIRequest() {
		super();
	}

	public static String getClientId() {
		return clientId;
	}

	public static void setClientId(String clientId) {
		APIRequest.clientId = clientId;
	}

	private void setHeader() throws SDKException {
		if (httpHeader == null) {
			httpHeader = new HttpHeaders();
		}

		if (APIRequest.clientId == null) {
			throw new SDKException("ESmartError005",
					SDKConstants.ESmartError005);
		}

		boolean existAuthorInfo = true;
		Class cls = null;
		try {
			cls = Class.forName("com.android.sdk.oauth.AuthorInfo");
			log(cls.toString());
		} catch (ClassNotFoundException e1) {
			existAuthorInfo = false;
		}

		httpHeader.put(SDKConstants.HEADER_CLIENT_ID, APIRequest.clientId);
		// Public Case를 위하여 Try Catch로 감쌈.
		if (existAuthorInfo) {
			String at = "";
			String rt = "";

			try {
				at = cls.getField("accessToken").get(cls).toString();
				rt = cls.getField("refreshToken").get(cls).toString();
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}

			log("Access Token : " + at);
			log("Refresh Token : " + rt);

			httpHeader.put(SDKConstants.HEADER_ACCESS_TOKEN, at);
			httpHeader.put(SDKConstants.HEADER_REFRESH_TOKEN, rt);
		}

	}

	/***
	 * POST Case
	 * 
	 * @param requestBundle
	 * @return
	 */
	private HttpUriRequest requestPost(RequestBundle requestBundle) {
		HttpPost httpPost = new HttpPost(urlConverter(requestBundle));
		StringEntity stringEntity = null;
		try {
			log("requestBundle.getPayload()" + requestBundle.getPayload());
			stringEntity = new StringEntity(requestBundle.getPayload(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		// Parameter가 Null 이 아니면.
		if (stringEntity != null) {
			log("[[Fat Body]]");
			httpPost.setEntity(stringEntity);
		} else {
			log("[[Null body.]]");
		}

		return httpPost;
	}

	/***
	 * POST Case ( File )
	 * 
	 * @param requestBundle
	 * @return
	 */
	private HttpUriRequest requestPostFile(RequestBundle requestBundle) {
		HttpPost httpPost = new HttpPost(urlConverter(requestBundle));

		// httpHeader.put("Content-Type", "multipart/form-data");

		httpHeader.headerMap.remove("Content-Type");

		MultipartEntity multiPartEntity = new MultipartEntity();
		FileBody fileBody = new FileBody(requestBundle.getUploadFile(),
				"multipart/form-data");
		multiPartEntity.addPart(requestBundle.getUploadFileKey(), fileBody);

		httpPost.setEntity(multiPartEntity);

		return httpPost;
	}

	/***
	 * PUT Case
	 * 
	 * @param requestBundle
	 * @return
	 */
	private HttpUriRequest requestPut(RequestBundle requestBundle) {
		HttpPut httpPut = new HttpPut(urlConverter(requestBundle));

		StringEntity stringEntity = null;
		try {
			stringEntity = new StringEntity(requestBundle.getPayload(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		// Parameter가 Null 이 아니면.
		if (stringEntity != null) {
			log("[[Fat Body]]");
			httpPut.setEntity(stringEntity);
		} else {
			log("[[Null body.]]");
		}

		return httpPut;
	}

	/***
	 * PUT Case ( File )
	 * 
	 * @param requestBundle
	 * @return
	 */
	private HttpUriRequest requestPutFile(RequestBundle requestBundle) {
		HttpPut httpPut = new HttpPut(urlConverter(requestBundle));

		// httpHeader.put("Content-Type", "multipart/form-data");

		httpHeader.headerMap.remove("Content-Type");

		MultipartEntity multiPartEntity = new MultipartEntity();
		FileBody fileBody = new FileBody(requestBundle.getUploadFile(),
				"multipart/form-data");
		multiPartEntity.addPart(requestBundle.getUploadFileKey(), fileBody);

		httpPut.setEntity(multiPartEntity);
		return httpPut;
	}

	/***
	 * 암호화
	 * 
	 * @return
	 */
	private String requestEncrypt() throws SDKException {

		HttpClient httpClient = null;
		/*
		 * requestBundle 설정
		 */
		RequestBundle requestBundle = new RequestBundle();
		requestBundle.setUrl(Constants.Url.OAUTH_ENCRYPT);
		String swapkey = String.valueOf(System.currentTimeMillis());
		requestBundle.setPayload("swap_key=" + swapkey + "&" + "client_id="
				+ getClientId());
		requestBundle.setHttpMethod(eSmartHttpMethod.POST);
		httpHeader.put("swap_key", swapkey);
		/*
		 * post 설정 설정
		 */
		HttpPost httpPost = new HttpPost(urlConverter(requestBundle));
		httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded");
		StringEntity stringEntity = null;
		try {
			log("requestBundle.getPayload()" + requestBundle.getPayload());
			stringEntity = new StringEntity(requestBundle.getPayload(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		// Parameter가 Null 이 아니면.
		if (stringEntity != null) {
			log("[[Fat Body]]");
			httpPost.setEntity(stringEntity);
		} else {
			log("[[Null body.]]");
		}

		HttpUriRequest requestBase = httpPost;

		if (SDKConstants.IS_DEBUG) {
			try {
				for (Header hd : requestBase.getAllHeaders()) {
					log("HEAD Key : " + hd.getName() + " / " + "HEAD Value : "
							+ hd.getValue());
				}
			} catch (Exception e) {
			}
		}

		if (requestBundle.getUrl().startsWith("https")) {
			log("Https!!");
			httpClient = getNewHttpClient();
		} else {
			log("Http!!");
			httpClient = new DefaultHttpClient();
		}

		String defaultUserAgent = System.getProperty("http.agent");

		String userAgentString = defaultUserAgent + "; "
				+ SDKConstants.SDK_VERSION_PREFIX + SDKConstants.SDK_VERSION;
		httpClient.getParams().setParameter(CoreProtocolPNames.USER_AGENT,
				userAgentString);

		if (SDKConstants.IS_DEBUG) {
			HttpParams hp = httpClient.getParams();
			String stringUa = hp.getParameter(CoreProtocolPNames.USER_AGENT)
					+ "";
			log("User agent : " + stringUa);
		}

		HttpResponse response = null;
		ResponseMessage returnMessage = null;

		try {
			log("requestBase : " + requestBase.getURI());

			response = httpClient.execute(requestBase);
			HttpEntity resEntity = response.getEntity();
			returnMessage = new ResponseMessage();

			returnMessage.setStatusCode(response.getStatusLine()
					.getStatusCode() + "");

			if ((resEntity != null) && (resEntity.getContentLength() > 0)) {
				returnMessage.setResultMessage(EntityUtils.toString(resEntity,
						"UTF-8"));
			} else {
				returnMessage.setResultMessage(EntityUtils.toString(resEntity,
						"UTF-8"));
				// returnMessage.setResultMessage("");
			}

			log("암호화 : " + returnMessage.getResultMessage());
			return returnMessage.getResultMessage();

		} catch (IOException e) {
			e.printStackTrace();
			SDKException e1 = new SDKException();
			e1.setMessage(e.getMessage());
			e1.setStackTrace(e.getStackTrace());
			throw e1;
		}
	}

	/***
	 * GET Case
	 * 
	 * @param requestBundle
	 * @return
	 */
	private HttpUriRequest requestGet(RequestBundle requestBundle) {
		HttpGet httpGet = new HttpGet(urlConverterEncrypt(requestBundle));
		return httpGet;
	}

	/***
	 * DELETE Case
	 * 
	 * @param requestBundle
	 * @return
	 */
	private HttpUriRequest requestDelete(RequestBundle requestBundle) {
		HttpDelete httpDelete = new HttpDelete(
				urlConverterEncrypt(requestBundle));
		return httpDelete;
	}

	private String urlConverter(RequestBundle requestBundle) {

		if (requestBundle.getParameters().size() == 0) {
			return requestBundle.getUrl();
		}

		StringBuilder sb = new StringBuilder();
		for (Entry<String, Object> e : requestBundle.getParameters().entrySet()) {
			if (sb.length() > 0) {
				sb.append('&');
			}
			try {
				String key = e.getKey();
				Object value = e.getValue();
				String valueTarget = objToString(value);

				sb.append(URLEncoder.encode(key, "UTF-8")).append('=')
						.append(URLEncoder.encode(valueTarget, "UTF-8"));
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			}
		}

		String returnValue = requestBundle.getUrl() + "?" + sb.toString();
		// String returnValue = requestBundle.getUrl() ;

		log("ENCODED URL : [" + returnValue + "]");
		return returnValue;
	}

	private String urlConverterEncrypt(RequestBundle requestBundle) {
		log("암호화 테스트 진행 ==");

		StringBuilder sb = new StringBuilder();
		for (Entry<String, Object> e : requestBundle.getParameters().entrySet()) {
			if (sb.length() > 0) {
				sb.append('&');
			}
			try {
				String key = e.getKey();
				Object value = e.getValue();
				String valueTarget = objToString(value);

				sb.append(URLEncoder.encode(key, "UTF-8")).append('=')
						.append(URLEncoder.encode(valueTarget, "UTF-8"));
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			}
		}

		try {
			JSONObject jsonObject = new JSONObject(requestEncrypt());
			JSONObject jsonData = new JSONObject(jsonObject.getString("body"));
			Encrypt bc = new Encrypt();

			bc.setkIV(jsonData.getString("iv"));
			bc.setkKey(jsonData.getString("key"));
			
			String returnValue = requestBundle.getUrl();
			if(sb.toString().trim().length()>0){
				returnValue = requestBundle.getUrl() + "?enc="
						+ bc.getEncrypt(sb.toString());
			}
		
			return returnValue;
		} catch (SDKException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String returnValue = requestBundle.getUrl() + "?" + sb.toString();
		// String returnValue = requestBundle.getUrl() ;

		return returnValue;
	}

	private String objToString(Object obj) {
		if (obj == null) {
			return "";
		}
		return String.valueOf(obj);
	}

	/***
	 * Request Main 제어부
	 * 
	 * @throws IOException
	 * @throws
	 */
	@Override
	public ResponseMessage request(RequestBundle requestBundle)
			throws SDKException {

		HttpClient httpClient = null;

		// 0. Set Init Header Info : OAuth Info Set to Header
		setHeader();

		// Request Setup
		// 1. set Url(not null) and set parameters( null value is ok )
		if ("".equals(requestBundle.getUrl()) || requestBundle.getUrl() == null) {
			throw new SDKException("ESmartError002",
					SDKConstants.ESmartError002);
		}
		if (requestBundle.getResponseType() == eSmartContentType.JSON) {
			requestBundle.setUrl(requestBundle.getUrl() + ".json");
		} else if (requestBundle.getResponseType() == eSmartContentType.XML) {
			requestBundle.setUrl(requestBundle.getUrl() + ".xml");
		}

		/*************** Accept / Content Type IS HERE *****************/
		// 2. set up to request payload type and result content type.
		String requestTypeString = SDKConstants.getContentType(requestBundle
				.getRequestType());
		String returnTypeString = SDKConstants.getContentType(requestBundle
				.getResponseType());

		httpHeader.put("Content-Type", requestTypeString);
		httpHeader.put("Accept", returnTypeString);

		if ("error".equals(returnTypeString)) {
			throw new SDKException("SDKConstants.ESmartError002",
					SDKConstants.ESmartError002);
		}

		// 3. set payload data (optional . )
		HttpUriRequest requestBase = null;
		switch (requestBundle.getHttpMethod()) {
		case PUT:
			if (requestBundle.getUploadFile() == null) {
				log("PUT : GENERAL");
				requestBase = requestPut(requestBundle);
			} else {
				log("PUT : FILEUPLOAD");
				requestBase = requestPutFile(requestBundle);
			}
			break;
		case POST:
			// Upload File의 경우 비어 있을 경우 FORM URL ENCODED 형식으로 보낼것인지,
			if (requestBundle.getUploadFile() == null) {
				requestBase = requestPost(requestBundle);
			} else {
				log("POST : FILEUPLOAD");
				requestBase = requestPostFile(requestBundle);
			}
			break;
		case GET:
			log("GET");
			requestBase = requestGet(requestBundle);
			break;
		case DELETE:
			log("DELETE");
			requestBase = requestDelete(requestBundle);
			break;
		default:
			throw new SDKException("SDKConstants.ESmartError001",
					SDKConstants.ESmartError001);
		}

		Map<String, String> map = httpHeader.getHeader();
		Set<Entry<String, String>> mapSet = map.entrySet();
		for (Entry<String, String> item : mapSet) {
			requestBase.addHeader(item.getKey(), item.getValue());
		}

		if (SDKConstants.IS_DEBUG) {
			try {
				for (Header hd : requestBase.getAllHeaders()) {
					log("HEAD Key : " + hd.getName() + " / " + "HEAD Value : "
							+ hd.getValue());
				}
			} catch (Exception e) {
			}
		}

		if (requestBundle.getUrl().startsWith("https")) {
			log("Https!!");
			httpClient = getNewHttpClient();
		} else {
			log("Http!!");
			httpClient = new DefaultHttpClient();
		}

		String defaultUserAgent = System.getProperty("http.agent");

		String userAgentString = defaultUserAgent + "; "
				+ SDKConstants.SDK_VERSION_PREFIX + SDKConstants.SDK_VERSION;
		httpClient.getParams().setParameter(CoreProtocolPNames.USER_AGENT,
				userAgentString);

		if (SDKConstants.IS_DEBUG) {
			HttpParams hp = httpClient.getParams();
			String stringUa = hp.getParameter(CoreProtocolPNames.USER_AGENT)
					+ "";
			log("User agent : " + stringUa);
		}

		HttpResponse response = null;
		ResponseMessage returnMessage = null;

		try {
			log("requestBase : " + requestBase.getURI());

			response = httpClient.execute(requestBase);
			HttpEntity resEntity = response.getEntity();
			returnMessage = new ResponseMessage();

			returnMessage.setStatusCode(response.getStatusLine()
					.getStatusCode() + "");

			if ((resEntity != null) && (resEntity.getContentLength() > 0)) {
				returnMessage.setResultMessage(EntityUtils.toString(resEntity,
						"UTF-8"));
			} else {
				returnMessage.setResultMessage(EntityUtils.toString(resEntity,
						"UTF-8"));
				// returnMessage.setResultMessage("");
			}
			
			// 암호화가 끝난후 기존 swap_key는 제거 한다.
			httpHeader.remove("swap_key");

		} catch (IOException e) {
			e.printStackTrace();
			SDKException e1 = new SDKException();
			e1.setMessage(e.getMessage());
			e1.setStackTrace(e.getStackTrace());
			throw e1;
		}

		return returnMessage;
	}

	public ResponseMessage request(RequestBundle bundle,
			eSmartHttpMethod httpMethod) throws SDKException {
		RequestBundle tossBundle = bundle;
		tossBundle.setHttpMethod(httpMethod);
		return request(tossBundle);
	}

	public ResponseMessage request(RequestBundle bundle, String url,
			eSmartHttpMethod httpMethod) throws SDKException {
		RequestBundle tossBundle = bundle;
		tossBundle.setHttpMethod(httpMethod);
		tossBundle.setUrl(url);
		return request(tossBundle);
	}

	@Override
	public void request(final RequestBundle requestBundle,
			final RequestListener requestListener) throws SDKException {
		if (requestListener == null) {
			throw new SDKException("SDKConstants.ESmartError004",
					SDKConstants.ESmartError004);
		}
		new Thread() {
			@Override
			public void run() {
				try {
					ResponseMessage resultString = request(requestBundle);
					requestListener.onComplete(resultString);
				} catch (SDKException e) {
					requestListener.onSDKException(e);
				}
			}
		}.start();
	}

	public void request(RequestBundle bundle, eSmartHttpMethod httpMethod,
			RequestListener requestListener) throws SDKException {
		RequestBundle tossBundle = bundle;
		tossBundle.setHttpMethod(httpMethod);
		tossBundle.setRequestListener(requestListener);
		request(tossBundle, requestListener);
	}

	public void request(RequestBundle bundle, String url,
			eSmartHttpMethod httpMethod, RequestListener requestListener)
			throws SDKException {
		RequestBundle tossBundle = bundle;
		tossBundle.setHttpMethod(httpMethod);
		tossBundle.setUrl(url);
		tossBundle.setRequestListener(requestListener);
		request(tossBundle, requestListener);
	}

	private void log(String log) {
		if (SDKConstants.IS_DEBUG) {
			System.out.println(log);
		}
	}

	public HttpClient getNewHttpClient() {
		try {
			KeyStore trustStore = KeyStore.getInstance(KeyStore
					.getDefaultType());
			trustStore.load(null, null);

			SSLSocketFactory sf = new MySSLSocketFactory(trustStore);
			sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

			HttpParams params = new BasicHttpParams();
			HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
			HttpProtocolParams.setContentCharset(params, HTTP.UTF_8);

			SchemeRegistry registry = new SchemeRegistry();
			registry.register(new Scheme("http", PlainSocketFactory
					.getSocketFactory(), 80));
			registry.register(new Scheme("https", sf, 443));

			ClientConnectionManager ccm = new ThreadSafeClientConnManager(
					params, registry);

			return new DefaultHttpClient(ccm, params);
		} catch (Exception e) {
			return new DefaultHttpClient();
		}
	}

}