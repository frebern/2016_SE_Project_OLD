package com.huk.sampleproject;

import android.content.Intent;
import android.os.Bundle;

import com.android.sdk.api.APIRequest;
import com.android.sdk.common.BaseActivity;
import com.android.sdk.oauth.OAuthInfoManager;

public class Init extends BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		initOAuthData();
		moveToMainPage();
	}

	public void initOAuthData() {
		
		APIRequest.setClientId("## ClientID값 입력 ##");
		OAuthInfoManager.clientSecret = "## ClientSecrent값 입력 ##";
		OAuthInfoManager.scope= "## Scope 입력ex) 101,102,103 ##";
		
	}
	
	public void moveToMainPage() {
		startActivity(new Intent(this, Main.class));
		finish();
	}

}
