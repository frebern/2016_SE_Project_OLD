package com.huk.sampleproject;

import java.util.HashMap;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.android.sdk.api.APIRequest;
import com.android.sdk.common.BaseActivity;
import com.android.sdk.common.RequestBundle;
import com.android.sdk.common.RequestListener;
import com.android.sdk.common.ResponseMessage;
import com.android.sdk.common.SDKConstants.eSmartHttpMethod;
import com.android.sdk.common.SDKException;

/** 사용자 정보 아이디검색 */
public class PublicGetTest2 extends BaseActivity {

	// API Call
	APIRequest api;
	RequestBundle requestBundle;

	// Comm Data
	String URL =  Const.SERVER + "/exam/test";

	
	TextView tv_content;
	EditText left_edt;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.content);

		initView();

	}

	public void initView() {
		tv_content = (TextView) findViewById(R.id.tv_content);
		findViewById(R.id.inputLayout).setVisibility(View.VISIBLE);

		findViewById(R.id.right_text).setVisibility(View.GONE);
		findViewById(R.id.left_edt).setVisibility(View.GONE);
		
		
		TextView left_text = (TextView)findViewById(R.id.left_text);
		left_text.setText(getResources().getString(R.string.input_userid));
		left_edt = (EditText)findViewById(R.id.right_edt);

	}

	public void onClickHandler(View v) {
		int id = v.getId();

		switch (id) {
		case R.id.btn_sync: {
			clearResult();
			requestASync();
			break;
		}
		case R.id.btn_async: {
			clearResult();
			requestSync();
			break;
		}
		default:
			break;
		}

	}

	public void initRequestBundle() {
		

		requestBundle = new RequestBundle();
		requestBundle.setUrl(URL);
		requestBundle.setHttpMethod(eSmartHttpMethod.GET);
//		requestBundle.setResponseType(eSmartContentType.XML);
		HashMap<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("userId", left_edt.getText().toString());
		requestBundle.setParameters(parameters);
		// requestBundle.setResponseType(eSmartContentType.JSON);
	}

	public void requestSync() {
		api = new APIRequest();
		initRequestBundle();

		ResponseMessage result = new ResponseMessage();
		try {
			result = api.request(requestBundle);
			setResult(result.getStatusCode() + "\n" + result.toString());

		} catch (SDKException e) {
			setResult(e.toString());
		}
	}

	public void clearResult() {
		setResult("");
	}

	public void setResult(String result) {
		tv_content.setText(result);
	}

	public void requestASync() {
		api = new APIRequest();
		initRequestBundle();

		try {
			api.request(requestBundle, reqListener);
		} catch (SDKException e) {
			e.printStackTrace();
		}
	}

	String hndResult = "";

	Handler msgHandler = new Handler() {
		public void dispatchMessage(Message msg) {
			setResult(hndResult);
		};
	};

	RequestListener reqListener = new RequestListener() {

		@Override
		public void onComplete(ResponseMessage result) {
			hndResult = result.getStatusCode() + "\n" + result.toString();
			msgHandler.sendEmptyMessage(0);
		}

		@Override
		public void onSDKException(SDKException e) {
			// TODO Auto-generated method stub
			hndResult = e.toString();
			msgHandler.sendEmptyMessage(0);

		}
	};

}
