package com.huk.sampleproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.android.sdk.common.BaseActivity;
import com.android.sdk.oauth.OAuthException;
import com.android.sdk.oauth.OAuthInfoManager;
import com.android.sdk.oauth.OAuthListener;

public class Main extends BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.main);
	

	}
	OAuthListener oauthlis = new OAuthListener() {
		@Override
		public void onError(String errorMessage) {
			System.out.println("onError : " + errorMessage);

		}
		
		@Override
		public void onComplete(String message) {
			System.out.println("onComplete : " + message);
		}
	};
	
	public void onClickHandler(View v) {

		int id = v.getId();

		switch (id) {
		case R.id.MAIN_BTN_LOGIN: {
			try {
				OAuthInfoManager.login(Main.this, oauthlis);
			} catch (OAuthException e) {
				e.printStackTrace();
			}
			break;
		}
		case R.id.MAIN_BTN_PUBLIC_GET: {
			startActivity(new Intent(this, PublicGetTest.class));
			break;
		}
		case R.id.MAIN_BTN_PUBLIC_GET2: {
			startActivity(new Intent(this, PublicGetTest2.class));
			break;
		}
		case R.id.MAIN_BTN_PRIVATE_POST: {
			startActivity(new Intent(this, PrivatePostTest.class));
			break;
		}
		case R.id.MAIN_BTN_PRIVATE_GET: {
			startActivity(new Intent(this, PrivateGetTest.class));
			break;
		}
		
		case R.id.MAIN_BTN_PRIVATE_PUT: {
			startActivity(new Intent(this, PrivatePutTest.class));
			break;
		}
		case R.id.MAIN_BTN_PRIVATE_DELETE: {
			startActivity(new Intent(this, PrivateDeleteTest.class));
			break;
		}
		case R.id.MAIN_BTN_LOGOUT : {
				OAuthInfoManager.logout(this, oauthlis);
			break;
		}
		
		default:
			break;
		}
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		System.exit(0);
		super.onDestroy();
	}
}
