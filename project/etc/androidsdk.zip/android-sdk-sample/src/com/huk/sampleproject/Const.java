package com.huk.sampleproject;

public class Const {
	
	public static String SERVER = "https://apidev.hanyang.ac.kr/rs";
	
}
 