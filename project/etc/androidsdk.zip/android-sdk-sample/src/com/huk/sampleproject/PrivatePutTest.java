package com.huk.sampleproject;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.android.sdk.api.APIRequest;
import com.android.sdk.common.BaseActivity;
import com.android.sdk.common.RequestBundle;
import com.android.sdk.common.RequestListener;
import com.android.sdk.common.ResponseMessage;
import com.android.sdk.common.SDKConstants.eSmartHttpMethod;
import com.android.sdk.common.SDKException;
/**사용자정보 수정*/
public class PrivatePutTest extends BaseActivity {

	//API Call
	APIRequest api;
	RequestBundle requestBundle;
	
	String URL = Const.SERVER + "/exam/modify";

	TextView tv_content;
	EditText edt_name, edt_phone;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.content);
		initView();

	}

	private void initView() {
		// TODO Auto-generated method stub
		tv_content = (TextView) findViewById(R.id.tv_content);
		findViewById(R.id.inputLayout).setVisibility(View.VISIBLE);

		TextView left_text = (TextView)findViewById(R.id.left_text);
		TextView right_text = (TextView)findViewById(R.id.right_text);
		
		left_text.setText(getResources().getString(R.string.input_name));
		right_text.setText(getResources().getString(R.string.input_phone));
        		
		edt_phone = (EditText)findViewById(R.id.right_edt);
		edt_name = (EditText)findViewById(R.id.left_edt);
	}

	public void onClickHandler(View v) {
		int id = v.getId();

		switch (id) {
		case R.id.btn_async: {
			clearResult();
			requestASync();
			break;
		}
		case R.id.btn_sync: {
			clearResult();
			requestSync();
			break;
		}
		default:
			break;
		}

	}

	public void initRequestBundle() {
		 
		try {
			JSONObject json = new JSONObject();
			json.put("name", edt_name.getText().toString());
			json.put("phone", edt_phone.getText().toString());
			
			requestBundle = new RequestBundle();
			requestBundle.setUrl(URL);
			requestBundle.setPayload(json.toString());
			requestBundle.setHttpMethod(eSmartHttpMethod.PUT);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void requestSync() {
		 api = new APIRequest();
		 initRequestBundle();
		
		 ResponseMessage result = new ResponseMessage();
		 try {
		 result = api.request(requestBundle);
		 setResult(result.getStatusCode() + "\n" + result.toString());
		 } catch (SDKException e) {
		 setResult(e.toString());
		 }
	}

	public void clearResult() {
		setResult("");
	}

	public void setResult(String result) {
		tv_content.setText(result);
	}

	public void requestASync() {
		api = new APIRequest();
		initRequestBundle();

		try {
			api.request(requestBundle, reqListener);
		} catch (SDKException e) {
			e.printStackTrace();
		}
	}

	String hndResult = "";

	Handler msgHandler = new Handler() {
		public void dispatchMessage(Message msg) {
			setResult(hndResult);
		};
	};

	RequestListener reqListener = new RequestListener() {

		@Override
		public void onSDKException(SDKException e) {
			hndResult = e.toString();
			msgHandler.sendEmptyMessage(0);
		}

		@Override
		public void onComplete(ResponseMessage result) {
			hndResult = result.getStatusCode() + "\n" + result.toString();
			msgHandler.sendEmptyMessage(0);
		}
	};

}
